#include <stdint.h>

void print_address_little_endian(uintptr_t address);
